package com.test.bank.AbcBank.repository;


import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.test.bank.AbcBank.AccountTransaction;
import com.test.bank.AbcBank.Customer;

@Repository
@Transactional
public class BankRepositoryImpl implements BankRepository{

	
	@Autowired
    private SessionFactory sessionFactory;
	
	
	@Override
	public String registerAccount(Customer customer) {
		Session session = sessionFactory.getCurrentSession();
		session.save(customer);
		return customer.getAccountNo();
	}

	@Override
	public Integer depositeAmount(AccountTransaction accTrans) {
		Session session = sessionFactory.getCurrentSession();
		session.save(accTrans);
		return accTrans.getBalance();
	}

	@Override
	public Integer withdrawAmount(AccountTransaction accTrans) {
		Session session = sessionFactory.getCurrentSession();
		session.save(accTrans);
		return accTrans.getBalance();
	}


	@Override
	public Customer findByAccountNumber(String accountNumber) {
		Session session = sessionFactory.getCurrentSession();
		
		String hql = "from Customer c where c.accountNo = :accountNumber";
		
		Query createQuery = session.createQuery(hql);
		createQuery.setParameter("accountNumber", accountNumber);
		Customer customer = (Customer) createQuery.uniqueResult();
		
		return customer;
	}

	
}
