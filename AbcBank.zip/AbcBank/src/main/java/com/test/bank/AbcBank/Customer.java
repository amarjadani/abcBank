package com.test.bank.AbcBank;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="CUSTOMER")
public class Customer {

	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer id;
	
	@Column(name="F_NAME")
	private String custFirstname;
	
	@Column(name="L_NAME")
	private String custLastName;
	
	@Column(name="PHONE")
	private Integer phone;
	
	@Column(name="ADDRESS")
	private String address;
	
	@Column(name="ACCOUNT_NO")
	private String accountNo;
	
	@Column(name="ACCOUNT_TYPE")
	private String accountType;
	
	@OneToMany(cascade = CascadeType.ALL,
            fetch = FetchType.EAGER,
            mappedBy = "customer")
	@OrderBy(value = "ID DESC")
    private List<AccountTransaction> transactions;
}
