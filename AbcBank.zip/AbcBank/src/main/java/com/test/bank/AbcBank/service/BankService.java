package com.test.bank.AbcBank.service;

import java.util.List;

import com.test.bank.AbcBank.AccountTransaction;
import com.test.bank.AbcBank.Customer;

public interface BankService {

	 public String registerAccount(Customer customer);
	 
	 public Customer findByAccountNumber(String accountNumber);
	 
	 public Integer depositeAmount(AccountTransaction accTrans);
	 
	 public AccountTransaction getLastTransaction(String accountNumber);
	 
	 public Integer withdrawAmount(AccountTransaction accTrans);
	 
	 public List<AccountTransaction> accountSummary(String accountNumber);
}
