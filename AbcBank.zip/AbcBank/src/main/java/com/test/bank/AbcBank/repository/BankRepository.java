package com.test.bank.AbcBank.repository;

import com.test.bank.AbcBank.AccountTransaction;
import com.test.bank.AbcBank.Customer;

public interface BankRepository {

	public String registerAccount(Customer customer);
	 
	 public Integer depositeAmount(AccountTransaction accTrans);
	 
	 public Integer withdrawAmount(AccountTransaction accTrans);
	 
	 public Customer findByAccountNumber(String accountNumber);
	 
}
