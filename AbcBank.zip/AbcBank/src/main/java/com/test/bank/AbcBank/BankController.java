package com.test.bank.AbcBank;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.test.bank.AbcBank.service.BankService;

@RestController
@RequestMapping(value = "/AbcBank")
public class BankController {

	@Autowired
	BankService bankService;
	
	@RequestMapping(value="/bankRegistration", method=RequestMethod.POST)
	@ResponseBody
    public String registerBankAccount(@RequestBody Customer customer) {
		customer.setAccountNo(ThreadLocalRandom.current().nextLong(910000001L, 910999999L)+"");
		return bankService.registerAccount(customer);
    }
	
	@RequestMapping(value="/dipositeAmount", method=RequestMethod.POST)
	@ResponseBody
    public Integer dipositeAmount(@RequestBody Map<String,Object> body) {
	
		Integer balance = null;
		
		String accountNo = body.get("accountNumber").toString();
		String description = body.get("description").toString();
		Integer amount = Integer.parseInt((String)body.get("amount"));
		AccountTransaction lastTransaction = bankService.getLastTransaction(accountNo);
		Integer balance2 = lastTransaction.getBalance();
		
		balance = amount + balance2;
		
		AccountTransaction at = new AccountTransaction();
		at.setAmount(amount);
		at.setBalance(balance);
		at.setDateTime(new Date());
		at.setDescription(description);
		at.setTranType("CR");
		return bankService.depositeAmount(at);
    }
	
	@RequestMapping(value="/withdrawAmount", method=RequestMethod.POST)
	@ResponseBody
    public Integer withdrawAmount(@RequestBody Map<String,Object> body) {
		Integer balance = null;
		String accountNo = body.get("accountNumber").toString();
		String description = body.get("description").toString();
		Integer amount = Integer.parseInt((String)body.get("amount"));
		AccountTransaction lastTransaction = bankService.getLastTransaction(accountNo);
		Integer balance2 = lastTransaction.getBalance();
		
		if(balance2!=null){
			balance = balance2 - amount;			
		}else{
			balance = 0 - amount;
		}
		
		AccountTransaction at = new AccountTransaction();
		at.setAmount(amount);
		at.setBalance(balance);
		at.setDateTime(new Date());
		at.setDescription(description);
		at.setTranType("DR");
		
		return bankService.withdrawAmount(at);
    }
	
	@RequestMapping(value="/accountSummary", method=RequestMethod.POST)
	@ResponseBody
    public List<AccountTransaction> summary(@RequestBody Map<String,Object> body) {
		String accountNo = body.get("accountNumber").toString();
		List<AccountTransaction> trx = new ArrayList<AccountTransaction>();
		return bankService.accountSummary(accountNo);
    }
}
