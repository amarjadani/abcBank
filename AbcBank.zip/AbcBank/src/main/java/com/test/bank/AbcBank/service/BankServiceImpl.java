package com.test.bank.AbcBank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.test.bank.AbcBank.AccountTransaction;
import com.test.bank.AbcBank.Customer;
import com.test.bank.AbcBank.repository.BankRepository;

@Service
@Transactional
public class BankServiceImpl  implements BankService{

	 @Autowired
	 BankRepository bankRepository;
	 
	 
	@Override
	public String registerAccount(Customer customer) {
		return bankRepository.registerAccount(customer);
	}

	@Override
	public Integer depositeAmount(AccountTransaction accTrans) {
		return bankRepository.depositeAmount(accTrans);
	}

	@Override
	public Integer withdrawAmount(AccountTransaction accTrans) {
		return bankRepository.withdrawAmount(accTrans);
	}

	@Override
	public List<AccountTransaction> accountSummary(String accountNumber) {
		return bankRepository.findByAccountNumber(accountNumber).getTransactions();
	}

	@Override
	public Customer findByAccountNumber(String accountNumber) {
		return bankRepository.findByAccountNumber(accountNumber);
	}

	@Override
	public AccountTransaction getLastTransaction(String accountNumber) {
		List<AccountTransaction> transactions = bankRepository.findByAccountNumber(accountNumber).getTransactions();
		if(transactions!=null && transactions.size()>0){
			return transactions.get(0);
		}
		return null;
	}

	
}
